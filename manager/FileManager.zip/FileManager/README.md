# FileManager
FileManager is Filesystem management, integrated mysql database management. Use on your Hosting or VPS...
## Author
- **Đồng Tuấn**

## Usage
- Just upload to your website
- Unzip FileManager.zip
- Run 'yourdomain.com/FileManager'
- Login with default :
                                         - Username: `admin`
                                         - Password: `12345`
- You can change your info in settings
